
import {useState} from 'react';
export default function App(){
const [msg]=useState('REST API Assignment UI');
return <h1>{msg}</h1>
}
