
const express=require('express');
const cors=require('cors');
const app=express();
app.use(cors());
app.use(express.json());
app.use('/api/v1/auth',require('./routes/authRoutes'));
app.use('/api/v1/tasks',require('./routes/taskRoutes'));
app.listen(process.env.PORT||5000,()=>console.log('Server running'));
