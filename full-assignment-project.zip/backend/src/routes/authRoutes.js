
const router=require('express').Router();
router.post('/register',(req,res)=>res.json({message:'register endpoint'}));
router.post('/login',(req,res)=>res.json({token:'jwt-token'}));
module.exports=router;
